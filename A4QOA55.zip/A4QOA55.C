#define QOA_IMPLEMENTATION
#include "qoa.h"
#include <allegro.h>
#include <stdio.h>
#include <stdlib.h>

extern void *qoa_read(const char *filename, qoa_desc *desc);

SAMPLE *load_qoa_sample(const char *filename) {
    FILE *f = fopen(filename, "rb");
    if (!f) {
        printf("Error: Cannot open file '%s'\n", filename);
        return NULL;
    }
    fclose(f);

    qoa_desc desc;
    printf("Calling qoa_read...\n");
    short *pcm_data = (short *)qoa_read(filename, &desc);
    if (!pcm_data) {
        printf("Error: qoa_read returned NULL.\n");
        return NULL;
    }
    printf("Decoded successfully. Samples: %d, Rate: %d\n", (int)desc.samples, (int)desc.samplerate);

    int bits = 16;
    int stereo = (desc.channels == 2) ? 1 : 0;
    
    printf("Creating Allegro sample structural buffer...\n");
    SAMPLE *spl = create_sample(bits, stereo, desc.samplerate, desc.samples);
    if (!spl) {
        printf("Error: create_sample failed.\n");
        return NULL;
    }

    printf("Flipping bits to Unsigned format...\n");
    long total_shorts = desc.samples * desc.channels;
    short *allegro_dest = (short *)spl->data;
    long i=0;
    for (i = 0; i < total_shorts; i++) {
        allegro_dest[i] = pcm_data[i] ^ 0x8000;
    }

    // DJGPP Fix: We skip calling free(pcm_data) here temporarily 
    // to rule out memory manager corruption crashes.

	// Set explicit loop constraints inside load_qoa_sample
    spl->loop_start = 0;
    spl->loop_end = desc.samples;

    return spl;
}

int main(int argc, char *argv[]) {
    if (argc < 2) {
        printf("Usage: %s <filename.qoa>\n", argv[0]);
        return 1;
    }

    if (allegro_init() != 0) {
        printf("Failed to init Allegro.\n");
        return 1;
    }

    install_keyboard();

    // DOS DRIVER RESET: 
    // Instead of DIGI_AUTODETECT, we use DIGI_SAFE or DIGI_SB16 
    // to prevent the DOS runtime from locking up on older hardware configurations.
    printf("Installing Allegro Sound System...\n");
    if (install_sound(DIGI_SB16, MIDI_NONE, NULL) != 0) {
        printf("SB16 failed. Trying safe fallback...\n");
        //if (install_sound(DIGI_SAFE, MIDI_NONE, NULL) != 0) {
        //    printf("Error initializing sound: %s\n", allegro_error);
            return 1;
        //}
    }

    SAMPLE *my_sound = load_qoa_sample(argv[1]);
    if (!my_sound) {
        printf("Sample creation aborted.\n");
        return 1;
    }

    printf("Attempting play_sample call...\n");
    //ORIG play_sample(my_sound, 255, 128, 1000, 0);
    //Hope no crackle now. YES! Also set DOSBOX fixed cycles to 20000
    play_sample(my_sound, 220, 128, 1000, 1);
    //Final numbered argument here if set to 1 will loop audio
    
    //The third number controls speed 1000 is default
    //TOO FAST play_sample(my_sound, 255, 128, my_sound->freq, 0);
    printf("Playing! Press ESC to exit.\n");

    while (!key[KEY_ESC]) {
        rest(10);
    }

    destroy_sample(my_sound);
    return 0;
}
END_OF_MAIN()
